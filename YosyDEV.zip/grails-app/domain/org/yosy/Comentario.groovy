package org.yosy

class Comentario {
	
	String email
	String autor
	String texto
	Date fecha

	static mapping = {
		id generator: 'native'
	}
	
	static constraints = {
	}
}
