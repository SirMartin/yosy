function logoutClick() {
	$('#linkRegistro').show();
	$('#linkLogin').show();
	$('#linkLogout').hide();
}
function loginClick() {
	$('#linkRegistro').hide();
	$('#linkLogin').hide();
	$('#linkLogout').show();
}